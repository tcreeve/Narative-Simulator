
public class KnownObject {
	Character characterKnows = new Character();
	Object objectKnown = new Object();
}
